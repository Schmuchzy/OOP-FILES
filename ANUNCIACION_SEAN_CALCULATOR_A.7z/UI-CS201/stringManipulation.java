
/**
 * Write a description of class stringManipulation here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner; 
public class stringManipulation
{
  public static void main(String [] args){
    Scanner input = new Scanner(System.in); 
    String myString = "Hello"; 
    System.out.println(myString.replace("l", "h")); 
       
    
    /*System.out.println("Input a String : " ); 
    String userUp = input.nextLine(); 
    System.out.println("This is your String in UpperCase > "+ userUp.toUpperCase());
    System.out.println("This is your String in LowerCase > " + userUp.toLowerCase()); 
    System.out.println("This is the Length of your String > " + userUp.length()); */
    
  }
  
}
