
/**
 * Write a description of class ignoreAndequals here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ignoreAndequals
{
 public static void main(String [] args){
     String name = "John"; 
     
     if(name .equals("John"))
         System.out.println("Hi, "  + name); 
     else if (name .equalsIgnoreCase("John"));
         System.out.println("Hey, have you seen " + name); 
     
     
     
 }
}
