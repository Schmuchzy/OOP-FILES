
/**
 * Write a description of class myWindow here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.*;
public class myWindow extends JFrame

{
    public static void main(String [] args)
    {
        JFrame window = new JFrame(); 
        window.setTitle("Anunciacion, Sean Timothy T.                               CS 201"); 
        window.setVisible(true); 
        //window.setSize(800,300); 
        //window.setLocation(0,0);
        window.setBounds(0,0,800,300); 
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
    }
  
}
