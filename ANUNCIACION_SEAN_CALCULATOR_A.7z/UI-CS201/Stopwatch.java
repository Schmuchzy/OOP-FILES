
/**
 * Write a description of class stopWatch here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Stopwatch extends JFrame
{
//Declare the controls

//Buttons
JButton startButton=new JButton();
JButton stopButton=new JButton();
JButton exitButton=new JButton();

//Labels
JLabel startLabel=new JLabel();
JLabel stopLabel=new JLabel();
JLabel elapsedLabel=new JLabel();

//Text Field
JTextField startTextField=new JTextField();
JTextField stopTextField=new JTextField();
JTextField elapsedTextField=new JTextField();

long startTime;
long stopTime;
double elapsedTime;
public Stopwatch(){
setTitle("Stopwatch Application");

addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e){
exitForm(e);
}
});

getContentPane().setLayout(new GridBagLayout());

//ADD CONTROLS
GridBagConstraints gridConstraints=new GridBagConstraints();


startButton.setText("Start Timing");
gridConstraints.gridx=0;
gridConstraints.gridy=0;
getContentPane().add(startButton,gridConstraints);

startButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        startButtonActionPerformed(e); 
    }
});



stopButton.setText("Stop Timing");
gridConstraints.gridx=0;
gridConstraints.gridy=1;
getContentPane().add(stopButton,gridConstraints);

stopButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        stopButtonActionPerformed(e); 
    }
});

exitButton.setText("Exit");
gridConstraints.gridx=0;
gridConstraints.gridy=2;
getContentPane().add(exitButton,gridConstraints);

exitButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        exitButtonActionPerformed(e); 
    }
});

//setSize(300,100);
pack(); //compress the window

//Add the Labels - for Label ng iinput na text
 startLabel.setText("Start Time");
 gridConstraints.gridx=1;
 gridConstraints.gridy=0;
 getContentPane().add((startLabel),gridConstraints);

 stopLabel.setText("Stop Time");
 gridConstraints.gridx=1;
 gridConstraints.gridy=1;
 getContentPane().add((stopLabel),gridConstraints);

 elapsedLabel.setText("Elapsed Time (sec)");
 gridConstraints.gridx=1;
 gridConstraints.gridy=2;
 getContentPane().add((elapsedLabel),gridConstraints);

//Add TextField - input number/text
 startTextField.setText("");
 startTextField.setColumns(15);
 gridConstraints.gridx=2;
 gridConstraints.gridy=0;
 getContentPane().add(startTextField,gridConstraints);

 stopTextField.setText("");
 stopTextField.setColumns(15);
 gridConstraints.gridx=2;
 gridConstraints.gridy=1;
 getContentPane().add(stopTextField,gridConstraints);

 elapsedTextField.setText("");
 elapsedTextField.setColumns(15);
 gridConstraints.gridx=2;
 gridConstraints.gridy=2;
 getContentPane().add(elapsedTextField,gridConstraints);
}
private void startButtonActionPerformed(ActionEvent e){
//System.exit(0);
JFrame f;
f=new JFrame();
JOptionPane.showMessageDialog(f,"START TIMER INITIATED");

}

private void stopButtonActionPerformed(ActionEvent e){
//System.exit(0);
JFrame f;
f=new JFrame();
JOptionPane.showMessageDialog(f,"STOP TIMER INITIATED");

}

private void exitButtonActionPerformed(ActionEvent e){
//System.exit(0);
JFrame f;
f=new JFrame();
JOptionPane.showMessageDialog(f,"EXIT TIMER INITIATED");

}




private void exitForm(WindowEvent e){
//System.exit(0);
JFrame f;
f=new JFrame();
JOptionPane.showMessageDialog(f,"Exiting Module");

}
public static void main(String[]args){
new Stopwatch().show(); //using show directly to the setVisible to true
}

}