
/**
 * Write a description of class TwoTestFrames here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.*;
import javax.swing.*;
public class TwoTestFrames
{
  public static void main(String [] args)
  {
      int height=100,width=200; 
      JFrame master = new JFrame("Click to Close Everything");
      
      //Parent Frame = closes everything
      master.setVisible(true); 
      master.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      master.setSize(400,300); 
      
      //Child Frame = closes part of the parent frame
      JFrame temp = new JFrame("Click to Close just This"); 
      temp.setVisible(true);
      temp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
      temp.setSize(300,200);
      
    
  }
}
