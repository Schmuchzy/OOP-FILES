
/**
 * Write a description of class TryToCompareStrings here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class TryToCompareStrings
{
    public static void main(String[] args)
    { 
        String aName = "Carmen";
        String anotherName;
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your Name > ");
        anotherName = input.nextLine();
        //if(aName == anotherName) <--- When comparing strings we don't use the ==  instead we use the .equals() function
        if(aName .equals (anotherName))
        System.out.println(aName + " equals " + anotherName);
        else
        System.out.println(aName + " does not equals " + anotherName);
        
        
    }
}
